import os
import os.path as op
import sys
import glob
import time
import pickle as pkl
import numpy as np
from types import SimpleNamespace
import shutil
import itertools
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import kendalltau, sem
from frrsa import frrsa
import json
import torch
from PIL import Image
import torchvision.transforms as transforms
from torch.utils.data import TensorDataset
import gc
from torch.profiler import profile, record_function, ProfilerActivity
from scipy import interpolate

sys.path.append(op.expanduser('~/david/master_scripts/DNN'))
from utils import (get_model, load_params, get_activations, plot_conv_filters,
                   receptivefield)
sys.path.append(op.expanduser('~/david/master_scripts/misc'))
from plot_utils import export_legend, custom_defaults
plt.rcParams.update(custom_defaults)

from in_vivo.fMRI.scripts.utils import CFG as fMRI
from in_vivo.fMRI.scripts.utils import RSA_dataset

sys.path.append(op.expanduser('~/david/repos/vonenet'))
from vonenet.vonenet import VOneNet


PROJ_DIR = op.expanduser('~/david/projects/p022_occlusion')
FMRI_DIR = op.join(PROJ_DIR, 'in_vivo/fMRI')

model_names = ['pixel', 'VOneNet', 'CORnet-S']
similarity = 'pearson'
norm = 'all-conds'
norm_method = 'zscore'
ylabel = "Correlation ($\it{r}$)"
measurements = 64
fix_stds = [0, 1 / 4, 1 / 2, 1]


def main(overwrite=False):

    os.chdir(f'{FMRI_DIR}/V1_models')

    evaluate_models(overwrite=overwrite)
    compare_models(overwrite=overwrite)
    compare_fixations(overwrite=True)
    compare_indices(overwrite=False)
    compare_reg_indices(overwrite=overwrite)
    measure_RF(overwrite=overwrite)
    evaluate_vis_ang(overwrite=overwrite)
    compare_vis_ang(overwrite=overwrite)
    compare_indices_vis_ang(overwrite=overwrite)
    compare_reg_indices_vis_ang(overwrite=overwrite)


def evaluate_models(overwrite=False):

    if not op.isfile('conditions.csv') or overwrite:
        norm = transforms.Normalize(mean=[0.5], std=[0.5])

        # dataset
        image_dir = f'{FMRI_DIR}/exp1/stimuli/all_stimuli'
        images = sorted(glob.glob(f'{image_dir}/*'))
        dataset = torch.empty((len(images), 3, 224, 224))
        image_counter = 0
        for cond in fMRI.cond_labels['exp1']:
            for im, image in enumerate(images):
                if cond in image:
                    image_PIL = Image.open(image).convert('RGB')
                    dataset[image_counter] = transforms.ToTensor()(image_PIL)
                    image_counter += 1

        df_conds = pd.DataFrame()
        df_indices = pd.DataFrame()
        df_indices_reg = pd.DataFrame()

        torch.no_grad()

        for model_name in model_names:

            if model_name == 'VOneNet':
                model = VOneNet(model_arch=None, visual_degrees=9,gabor_seed=1)
                out_dir = f'{PROJ_DIR}/in_silico/models/VOneNet/fMRI'
                layer = 'VOneBlock'
                for filter_set in ['simple_conv_q0', 'simple_conv_q1']:
                    filters = model.state_dict()[f'{filter_set}.weight']
                    outpath = f'{out_dir}/kernel_plots/{filter_set}.png'
                    plot_conv_filters(filters=filters, outpath=outpath)

            elif model_name == 'CORnet-S':
                model = get_model('cornet_s')
                params = '/mnt/HDD1_12TB/repos/CORnet-master/cornet/cornet_s-1d3f7974.pth'
                model = load_params(params, model, 'model')
                model = model.V1
                out_dir = (f'{PROJ_DIR}/in_silico/models/cornet_s/pretrained'
                           f'/fMRI')
                layer = 'V1'
                filters = model.state_dict()['conv1.weight']
                outpath = f'{out_dir}/kernel_plots/V1.png'
                plot_conv_filters(filters=filters, outpath=outpath)

            else:
                def model(inputs):
                    return inputs
                out_dir = f'{PROJ_DIR}/in_silico/models/pixel/fMRI'
                layer = 'pixel'

            for fix_std in fix_stds:

                print(f'Measuring activations {model_name} {fix_std}')
                if fix_std == 0:
                    inputs = norm(dataset)
                    responses = model(inputs).flatten(start_dim=1).detach().numpy()
                else:
                    scale = fix_std * 14
                    responses = [[], []]
                    for m in range(measurements//2):
                        print(f'Measuring activations {model_name} {fix_std} m'
                              f'{m+1}/{measurements}')
                        for side in range(2):
                            inputs = dataset.clone()
                            for i, image in enumerate(dataset):
                                ecc = np.abs(np.random.normal(loc=0, scale=scale))
                                ang = np.random.uniform(low=0, high=2 * np.pi)
                                x = int(ecc * np.cos(ang))
                                y = int(ecc * np.sin(ang))
                                inputs[i] = transforms.functional.affine(
                                    img=image, angle=0, translate=(x, y),
                                    scale=1., shear=0., fill=.5)
                            inputs = norm(inputs)
                            responses[side].append(model(inputs).flatten(
                                start_dim=1).detach().numpy())

                        #for i in range(24):
                        #    plt.imshow(transforms.ToPILImage()(inputs[i]))
                        #    plt.show()
                        #    time.sleep(2)
                        #    plt.imshow(transforms.ToPILImage()(
                        #        responses[1, 31, i, 0, :, :] * 100))
                        #    plt.show()
                        #    time.sleep(2)

                    # average across measurements
                    responses = np.array(responses).mean(axis=1)

                # make RSA dataset and calculate RSM
                print(f'Calculating RSM')
                os.makedirs(f'{out_dir}', exist_ok=True)
                RSM = RSA_dataset(responses=responses).calculate_RSM(
                    norm, norm_method, similarity)

                # plot RSM
                print(f'Plotting RSM ')
                RSM.plot_RSM(
                    vmin=-1, vmax=1,
                    fancy=True,
                    title=f'layer: {layer}',
                    labels=fMRI.cond_labels['exp1'],
                    outpath=f'{out_dir}/RSMs/{layer}_fixrng-{fix_std:.3f}.png',
                    measure=ylabel)

                # MDS
                print(f'Plotting MDS')
                outpath = f'{out_dir}/MDS/{layer}_fixrng-{fix_std:.3f}.png'
                RSM.plot_MDS(
                    title=None,
                    outpath=outpath)

                # perform contrasts
                RSM.RSM_to_table()
                RSM.calculate_occlusion_robustness()
                RSM.fit_models()
                df = RSM.occlusion_robustness.copy(deep=True)
                df['model'] = model_name
                df['fix_std'] = fix_std
                df_indices = pd.concat([df_indices, df]).reset_index(drop=True)

                # condition-wise similarities
                df = RSM.RSM_table.copy(deep=True)
                df = df.drop(columns=['exemplar_a', 'exemplar_b', 'occluder_a',
                    'occluder_b']).groupby(['analysis', 'level']).agg('mean'). \
                    dropna().reset_index()
                df['model'] = model_name
                df['fix_std'] = fix_std
                df_conds = pd.concat([df_conds, df.copy(deep=True)]).reset_index(
                    drop=True)

                # regression-based indices
                df = pd.DataFrame({'model': [model_name]*2,
                                   'fix_std': [fix_std]*2,
                                   'analysis': [
                                       'exemplar_v_occluder_position',
                                       'exemplar_v_occluder_presence'],
                                   'value': [RSM.exemplar_v_occluder_position,
                                             RSM.exemplar_v_occluder_presence],
                                   })
                df_indices_reg = pd.concat([df_indices_reg, df]).reset_index(
                    drop=True)

        df_conds.to_csv('conditions.csv')
        df_indices.to_csv('indices.csv')
        df_indices_reg.to_csv('indices_reg.csv')


# compare models at each fix std
def compare_models(overwrite=False):

    ylims = [-.8, 1.0]
    df_indices = pd.read_csv('indices.csv', index_col=0)
    df_conds = pd.read_csv('conditions.csv', index_col=0)

    # ensure levels are ordered correctly
    level_order = fMRI.occlusion_robustness_analyses[
                      'object_completion']['conds'] + \
                  fMRI.occlusion_robustness_analyses[
                      'occlusion_invariance']['conds']
    df_conds.level = df_conds.level.astype('category').cat.reorder_categories(
        level_order)
    df_conds.model = df_conds.model.astype('category').cat.reorder_categories(
        model_names)

    for fix_std in fix_stds:

        for analysis, params in fMRI.occlusion_robustness_analyses.items():

            out_dir = f'{analysis}'
            os.makedirs(out_dir, exist_ok=True)
            outpath = (f'{out_dir}/condition-wise_similarities_fixrng-'
                       f'{fix_std:.3f}.png')

            if not op.isfile(outpath) or overwrite:

                df_analysis = df_conds[(df_conds.analysis == analysis) &
                                       (df_conds.fix_std == fix_std)]
                df_index = df_indices[(df_indices.analysis == analysis) &
                                        (df_indices.fix_std == fix_std)]

                x_labels = []
                for model_name in model_names:
                    index_value = df_index.value[(df_index.model == model_name) &
                                                    (df_index.subtype == 'norm')].item()
                    x_labels.append(f'{model_name}\n{index_value:.3f}')

                df_means = df_analysis.pivot(index='model', columns='level',
                                             values='similarity')
                df_plot = df_means.plot(kind='bar',
                                        rot=0,
                                        figsize=(5,5),
                                        color=params['colours'],
                                        legend=False)
                fig = df_plot.get_figure()
                plt.yticks(np.arange(-.5, 1.1, .5), size=18)
                plt.ylim(ylims)
                plt.ylabel(ylabel, size=16)
                plt.title(f"{analysis.replace('_',' ')} sigma={fix_std}", size=20, pad=25)
                plt.xticks(size=16, labels=x_labels, ticks=[0,1,2])
                plt.text(-1, -.25+ylims[0], f'{params["index_label"]}:', fontsize=16)
                plt.tight_layout()
                fig.savefig(outpath)
                plt.show()

                # legend
                outpath = f'{out_dir}/condition-wise_similarities_legend.pdf'
                f = lambda m, c: \
                    plt.plot([], [], marker=m, markerfacecolor=c, color='white')[0]
                handles = [f('s', colour) for colour in params['colours']]
                legend = plt.legend(handles, params['labels'], loc=3)
                export_legend(legend, filename=outpath)
                plt.close()


# compare fix_stds for each model
def compare_fixations(overwrite=False):

    df_indices = pd.read_csv('indices.csv', index_col=0)
    df_conds = pd.read_csv('conditions.csv', index_col=0)

    # ensure levels are ordered correctly
    level_order = fMRI.occlusion_robustness_analyses[
                      'object_completion']['conds'] + \
                  fMRI.occlusion_robustness_analyses[
                      'occlusion_invariance']['conds']
    df_conds.level = df_conds.level.astype('category').cat.reorder_categories(
        level_order)
    df_conds.model = df_conds.model.astype('category').cat.reorder_categories(
        model_names)
    for analysis, params in fMRI.occlusion_robustness_analyses.items():

        out_dir = f'{analysis}'
        os.makedirs(out_dir, exist_ok=True)
        outpath = (f'{out_dir}/condition-wise_similarities.png')

        if not op.isfile(outpath) or overwrite:

            fig, axes = plt.subplots(nrows=3, figsize=(4,4.5), sharex=True)

            for ax, model_name in zip(axes, model_names):

                df_analysis = df_conds[(df_conds.analysis == analysis) &
                                       (df_conds.model == model_name) &
                                       (df_conds.fix_std.isin(fix_stds))]
                df_index = df_indices[(df_indices.analysis == analysis) &
                                      (df_indices.model == model_name) &
                                       (df_indices.fix_std.isin(fix_stds))]
                index_values = []
                for f, fix_std in enumerate(fix_stds):
                    index_value = df_index.value[(df_index.fix_std == fix_std) &
                                                 (df_index.subtype == 'norm')].item()
                    index_values.append(index_value)

                df_means = df_analysis.pivot(index='fix_std', columns='level',
                                             values='similarity')
                df_means.plot(
                    kind='bar',
                    rot=0,
                    color=params['colours'],
                    legend=False,
                    ax=ax)
                ax.set_yticks(np.arange(-1, 1.1, 1))
                ax.set_ylim((-1, 1.0))
                if model_name == 'VOneNet':
                    ax.set_ylabel(ylabel)
                else:
                    ax.set_ylabel(None)
                ax.set_title(model_name, pad=5)
                ax.set_xticks(labels=fix_stds, ticks=np.arange(len(fix_stds)))
                #plt.text(index_x, index_y, index_texts, fontsize=16)
            plt.xlabel(r"spatial jitter $\sigma$ ($\degree$)")
            plt.tight_layout()
            fig.savefig(outpath)
            plt.close()


# compare robustness indices for each model
def compare_indices(overwrite=False):

    df_indices = pd.read_csv('indices.csv', index_col=0)

    for analysis, params in fMRI.occlusion_robustness_analyses.items():

        out_dir = f'{analysis}'
        outpath = f'{out_dir}/{params["index_label"]}.png'

        if not op.isfile(outpath) or overwrite:

            fig, ax = plt.subplots(figsize=(3.5,2))
            x_pos = np.arange(len(fix_stds))
            colours = {
                'pixel': 'tab:gray',
                'VOneNet': 'tab:pink',
                'CORnet-S': 'tab:purple',
            }

            fMRI_vals = []
            linestyles = ['solid', 'dashed', 'dotted']
            for exp, task in zip(
                    ['exp1', 'exp2', 'exp2'],
                    ['occlusion', 'occlusionAttnOn', 'occlusionAttnOff']):
                fMRI_data = pd.read_csv(
                    f'{FMRI_DIR}/{exp}/derivatives/RSA/'
                    f'{task}_space-standard/norm-all-conds_z-score/'
                    f'pearson/{analysis}/indices.csv')
                fMRI_vals.append(fMRI_data['value'][
                                     (fMRI_data.level == 'group') &
                                     (fMRI_data.subtype == 'norm') &
                                     (fMRI_data.region == 'V1')].item())

            for model_name in model_names:

                df_index = df_indices[(df_indices.analysis == analysis) &
                                      (df_indices.model == model_name) &
                                       (df_indices.fix_std.isin(fix_stds))]


                index_values = []
                for f, fix_std in enumerate(fix_stds):
                    index_value = df_index.value[(df_index.fix_std == fix_std) &
                                                 (df_index.subtype == 'norm')].item()
                    index_values.append(index_value)

                ax.plot(x_pos,
                    index_values,
                    color=colours[model_name],
                    marker='o',
                    markerfacecolor='white',
                    lw=2,)

            ceiling_x = np.arange(-.5,len(fix_stds) + .5)
            ax.fill_between(ceiling_x, 1.0, 2, color='black', alpha=.2, lw=0)
            ax.fill_between(ceiling_x, 0, -1, color='black', alpha=.2, lw=0)
            ax.set_yticks((0, .5, 1), labels=['0','.5','1'])
            ax.set_ylabel(params['index_label'])
            ax.set_ylim((-0.1, 1.2))
            for fMRI_val, ls in zip(fMRI_vals, linestyles):
                ax.axhline(y=fMRI_val, xmin=-.5, xmax=len(fix_stds) + .5,
                           color='tab:blue', ls=ls)
            ax.set_xticks(ticks=x_pos, labels=fix_stds)
            ax.set_xlim((-.5, len(fix_stds) - .5))
            ax.set_title(f"{analysis.replace('_', ' ')} index")
            ax.set_xlabel(r"spatial jitter $\sigma$ ($\degree$)")
            plt.tight_layout()
            plt.savefig(outpath, dpi=300)
            plt.close()

            # legend
            f = lambda m, c, mec, ls: plt.plot(
                [], [], marker=m, c=c, mec=mec, ls=ls)[0]
            labels = [
                'Human V1 (Exp. 1, object discrimination)',
                'Human V1 (Exp. 2, object discrimination)',
                'Human V1 (Exp. 2, character detection)'] + model_names
            markers = [None, None, None, 'o', 'o', 'o']
            lss = ['solid', 'dashed', 'dotted', None, None, None]
            mecs = [None]*3 + [colours[m] for m in model_names]
            cols = ['tab:blue']*3 + ['white']*3
            handles = [f(m, c, mec, ls) for m, c, mec, ls in zip(
                markers, cols, mecs, lss)]
            legend = plt.legend(handles, labels, loc=3)
            export_legend(legend, filename=f'model_legend.pdf')
            plt.close()


# compare regression-based indices for each model
def compare_reg_indices(overwrite=False):

    df_indices = pd.read_csv('indices_reg.csv', index_col=0)
    out_dir = f'regression'
    os.makedirs(out_dir, exist_ok=True)
    for analysis in df_indices.analysis.unique():


        outpath = f'{out_dir}/{analysis}.png'

        if not op.isfile(outpath) or overwrite:

            fig, ax = plt.subplots(figsize=(5.5,5))
            x_pos = np.arange(len(fix_stds))
            colours = {
                'pixel': 'tab:gray',
                'VOneNet': 'tab:pink',
                'CORnet-S': 'tab:purple',
            }

            fMRI_vals = []
            fMRI_task_labels = [
                'Exp. 1 (object discrimination)',
                'Exp. 2 (object discrimination)',
                'Exp. 2 (character detection)']
            linestyles = ['solid', 'dashed', 'dotted']
            for exp, task in zip(
                    ['exp1', 'exp2', 'exp2'],
                    ['occlusion', 'occlusionAttnOn', 'occlusionAttnOff']):
                fMRI_data = pd.read_csv(
                    f'{FMRI_DIR}/{exp}/derivatives/RSA/'
                    f'{task}_space-standard/norm-all-conds_z-score/'
                    f'pearson/{analysis}/indices.csv')
                fMRI_vals.append(fMRI_data['value'][
                                     (fMRI_data.level == 'group') &
                                     (fMRI_data.subtype == 'norm') &
                                     (fMRI_data.region == 'V1')].item())

            ax.axhline(y=0, xmin=-.5, xmax=len(fix_stds) + .5, color='black')
            for model_name in model_names:

                df_index = df_indices[(df_indices.analysis == analysis) &
                                      (df_indices.model == model_name) &
                                       (df_indices.fix_std.isin(fix_stds))]


                index_values = []
                for f, fix_std in enumerate(fix_stds):
                    index_value = df_index.value[
                        df_index.fix_std == fix_std].item()
                    index_values.append(index_value)

                ax.plot(x_pos,
                    index_values,
                    color=colours[model_name],
                    marker='o',
                    markerfacecolor='white',
                    lw=2,)

            ceiling_x = np.arange(-.5, len(fix_stds) + .5)
            ax.fill_between(ceiling_x, 1.0, 2, color='black', alpha=.2, lw=0)
            ax.fill_between(ceiling_x, -2, -1, color='black', alpha=.2, lw=0)
            ax.set_yticks((-1,0,1), size=16)
            ax.set_ylabel('occluder <-----> exemplar', size=16)
            ax.set_ylim((-1.2, 1.2))
            ax.set_xticks(ticks=x_pos, labels=fix_stds,  size=16)
            ax.set_xlim((-.5, len(fix_stds) - .5))
            ax.set_xlabel(r"spatial jitter $\sigma$ ($\degree$)", size=16)
            plt.tight_layout()
            plt.savefig(outpath, dpi=300)
            plt.close()


# measure RF size for VOneNet and CORnet-S
def measure_RF(overwrite=False):

    if not op.isfile('RF_sizes.csv') or overwrite:

        RF_sizes = pd.DataFrame()
        for model_name in ['CORnet-S', 'VOneNet']:

            # get RF size in pixels
            if model_name == 'VOneNet':
                model = VOneNet(model_arch=None, visual_degrees=9)
                RF_size_pix = model.k_exc
            elif model_name == 'CORnet-S':
                model = get_model('cornet_s').V1
                RF = receptivefield(model, (1, 3, 224, 224))
                RF_size_pix = RF.rfsize[0]

            # convert to degrees
            RF_size_deg = RF_size_pix * 9 / 224

            # add to data frame
            RF_sizes = pd.concat([RF_sizes, pd.DataFrame(
                {'model': [model_name],
                 'RF_size_pix': [RF_size_pix],
                 'RF_size_deg': [RF_size_deg]})]).reset_index(drop=True)
        # save
        RF_sizes.to_csv('RF_sizes.csv')


def evaluate_vis_ang(overwrite=False):

    if not op.isfile('conditions_VOne-vis-ang.csv') or overwrite:

        norm = transforms.Normalize(mean=[0.5], std=[0.5])

        # dataset
        image_dir = f'{FMRI_DIR}/exp1/stimuli/all_stimuli'
        images = sorted(glob.glob(f'{image_dir}/*'))
        dataset = torch.empty((len(images), 3, 224, 224))
        image_counter = 0
        for cond in fMRI.cond_labels['exp1']:
            for im, image in enumerate(images):
                if cond in image:
                    image_PIL = Image.open(image).convert('RGB')
                    dataset[image_counter] = transforms.ToTensor()(image_PIL)
                    image_counter += 1

        df_conds = pd.DataFrame()
        df_indices = pd.DataFrame()
        df_indices_reg = pd.DataFrame()

        torch.no_grad()


        for vis_ang in [2.25, 4.5, 9, 18, 36]:

            print(f'Measuring activations VOneNet {vis_ang} degrees')
            model = VOneNet(model_arch=None, visual_degrees=vis_ang,
                            gabor_seed=1)
            out_dir = f'{PROJ_DIR}/in_silico/models/VOneNet/fMRI'
            layer = 'VOneBlock'
            for filter_set in ['simple_conv_q0', 'simple_conv_q1']:
                filters = model.state_dict()[f'{filter_set}.weight']
                outpath = f'{out_dir}/kernel_plots/{filter_set}.png'
                plot_conv_filters(filters=filters, outpath=outpath)

            inputs = norm(dataset)
            responses = model(inputs).flatten(start_dim=1).detach().numpy()

            # make RSA dataset and calculate RSM
            print(f'Calculating RSM')
            os.makedirs(f'{out_dir}', exist_ok=True)
            RSM = RSA_dataset(responses=responses).calculate_RSM(
                norm, norm_method, similarity)

            # plot RSM
            print(f'Plotting RSM ')
            RSM.plot_RSM(
                vmin=-1, vmax=1,
                fancy=True,
                title=f'layer: {layer}',
                labels=fMRI.cond_labels['exp1'],
                outpath=f'{out_dir}/RSMs/{layer}_vis-ang-{vis_ang:.3f}.png',
                measure=ylabel)

            # MDS
            print(f'Plotting MDS')
            outpath = f'{out_dir}/MDS/{layer}_vis-ang-{vis_ang:.3f}.png'
            RSM.plot_MDS(
                title=None,
                outpath=outpath)

            # perform contrasts
            RSM.RSM_to_table()
            RSM.calculate_occlusion_robustness()
            RSM.fit_models()
            df = RSM.occlusion_robustness.copy(deep=True)
            df['vis_ang'] = vis_ang
            df_indices = pd.concat([df_indices, df]).reset_index(drop=True)

            # condition-wise similarities
            df = RSM.RSM_table.copy(deep=True)
            df = df.drop(columns=['exemplar_a', 'exemplar_b', 'occluder_a',
                'occluder_b']).groupby(['analysis', 'level']).agg('mean'). \
                dropna().reset_index()
            df['vis_ang'] = vis_ang
            df_conds = pd.concat([df_conds, df.copy(deep=True)]).reset_index(
                drop=True)

            # regression-based indices
            df = pd.DataFrame({'vis_ang': [vis_ang] * 2,
                               'analysis': [
                                   'exemplar_v_occluder_position',
                                   'exemplar_v_occluder_presence'],
                               'value': [RSM.exemplar_v_occluder_position,
                                         RSM.exemplar_v_occluder_presence],
                               })
            df_indices_reg = pd.concat([df_indices_reg, df]).reset_index(
                drop=True)

        df_conds.to_csv('conditions_VOne-vis-ang.csv')
        df_indices.to_csv('indices_VOne-vis-ang.csv')
        df_indices_reg.to_csv('indices_reg_VOne-vis-ang.csv')


def compare_vis_ang(overwrite=False):

    ylims = [-.8, 1.0]
    df_indices = pd.read_csv('indices_VOne-vis-ang.csv', index_col=0)
    df_conds = pd.read_csv('conditions_VOne-vis-ang.csv', index_col=0)
    vis_angs = [2.25, 4.5, 9, 18, 36]

    # ensure levels are ordered correctly
    level_order = fMRI.occlusion_robustness_analyses[
                      'object_completion']['conds'] + \
                  fMRI.occlusion_robustness_analyses[
                      'occlusion_invariance']['conds']
    df_conds.level = df_conds.level.astype('category').cat.reorder_categories(
        level_order)

    for analysis, params in fMRI.occlusion_robustness_analyses.items():

        out_dir = f'{analysis}'
        os.makedirs(out_dir, exist_ok=True)
        outpath = (f'{out_dir}/condition-wise_similarities_model-'
                   f'VOneNet_vis-ang.png')

        if not op.isfile(outpath) or overwrite:

            df_analysis = df_conds[(df_conds.analysis == analysis) &
                                   (df_conds.vis_ang.isin(vis_angs))]
            df_index = df_indices[(df_indices.analysis == analysis) &
                                   (df_indices.vis_ang.isin(vis_angs))]
            index_values = []
            for f, vis_ang in enumerate(vis_angs):
                index_value = df_index.value[(df_index.vis_ang == vis_ang) &
                                             (df_index.subtype == 'norm')].item()
                index_values.append(index_value)

            df_means = df_analysis.pivot(index='vis_ang', columns='level',
                                         values='similarity')
            df_plot = df_means.plot(kind='bar',
                                    rot=0,
                                    figsize=(7, 4),
                                    color=params['colours'],
                                    legend=False)
            fig = df_plot.get_figure()
            plt.yticks(np.arange(-.5, 1.1, .5), size=16)
            plt.ylim(ylims)
            plt.xlabel(r"visual angle ($\degree$)", size=16)
            plt.ylabel(ylabel, size=16)
            plt.title('VOneNet', size=20, pad=25)
            plt.xticks(size=16, labels=vis_angs, ticks=np.arange(len(vis_angs)))
            #plt.text(index_x, index_y, index_texts, fontsize=16)
            plt.tight_layout()
            fig.savefig(outpath)
            plt.show()


def compare_indices_vis_ang(overwrite=False):

    df_indices = pd.read_csv('indices_VOne-vis-ang.csv', index_col=0)
    vis_angs = [2.25, 4.5, 9, 18, 36]

    for analysis, params in fMRI.occlusion_robustness_analyses.items():

        out_dir = f'{analysis}'
        outpath = f'{out_dir}/{params["index_label"]}_VOne_vis_ang.png'

        if not op.isfile(outpath) or overwrite:

            fig, ax = plt.subplots(figsize=(5.5,5))
            x_pos = np.arange(len(vis_angs))
            colours = {
                'pixel': 'tab:gray',
                'VOneNet': 'tab:pink',
                'CORnet-S': 'tab:purple',
            }

            fMRI_vals = []
            fMRI_task_labels = [
                'Exp. 1 (object discrimination)',
                'Exp. 2 (object discrimination)',
                'Exp. 2 (character detection)']
            linestyles = ['solid','dashed', 'dotted']
            for exp, task in zip(
                    ['exp1','exp2','exp2'],
                    ['occlusion', 'occlusionAttnOn', 'occlusionAttnOff']):
                fMRI_data = pd.read_csv(
                    f'{FMRI_DIR}/{exp}/derivatives/RSA/'
                    f'{task}_space-standard/norm-all-conds_z-score/'
                    f'pearson/{analysis}/indices.csv')
                fMRI_vals.append(fMRI_data['value'][
                    (fMRI_data.level == 'group') &
                    (fMRI_data.subtype == 'norm') &
                    (fMRI_data.region == 'V1')].item())

            df_index = df_indices[(df_indices.analysis == analysis) &
                                   (df_indices.vis_ang.isin(vis_angs))]


            index_values = []
            for f, vis_ang in enumerate(vis_angs):
                index_value = df_index.value[(df_index.vis_ang == vis_ang) &
                                             (df_index.subtype == 'norm')].item()
                index_values.append(index_value)

            ax.plot(x_pos,
                index_values,
                color=colours['VOneNet'],
                marker='o',
                markerfacecolor='white',
                lw=2,)

            ceiling_x = np.arange(-.5,len(vis_angs) + .5)
            ax.fill_between(ceiling_x, 1.0, 2, color='black', alpha=.2, lw=0)
            for fMRI_val, ls in zip(fMRI_vals, linestyles):
                ax.axhline(y=fMRI_val, xmin=-.5, xmax=len(vis_angs) + .5,
                           color='tab:blue', ls=ls)
            ax.set_yticks((0, .5, 1), labels=['0','.5','1'], size=16)
            ax.set_ylabel(params['index_label'], size=16)
            ax.set_ylim((-.5, 1.2))
            ax.set_xticks(ticks=x_pos, labels=vis_angs,  size=16)
            ax.set_xlim((-.5, len(vis_angs) - .5))
            ax.set_xlabel(r"visual angle ($\degree$)", size=16)
            plt.tight_layout()
            plt.savefig(outpath, dpi=300)
            plt.close()


def compare_reg_indices_vis_ang(overwrite=False):

    df_indices = pd.read_csv('indices_reg_VOne-vis-ang.csv', index_col=0)
    vis_angs = [2.25, 4.5, 9, 18, 36]
    out_dir = f'regression'

    for analysis in df_indices.analysis.unique():

        outpath = f'{out_dir}/{analysis}_vis_ang.png'

        if not op.isfile(outpath) or overwrite:

            fig, ax = plt.subplots(figsize=(5.5,5))
            x_pos = np.arange(len(vis_angs))
            colours = {
                'pixel': 'tab:gray',
                'VOneNet': 'tab:pink',
                'CORnet-S': 'tab:purple',
            }

            df_index = df_indices[(df_indices.analysis == analysis) &
                                   (df_indices.vis_ang.isin(vis_angs))]


            index_values = []
            for f, vis_ang in enumerate(vis_angs):
                index_value = df_index.value[df_index.vis_ang == vis_ang].item()
                index_values.append(index_value)

            ax.axhline(y=0, xmin=-.5, xmax=len(vis_angs) + .5, color='black')
            ax.plot(x_pos,
                index_values,
                color=colours['VOneNet'],
                marker='o',
                markerfacecolor='white',
                lw=2,)

            ceiling_x = np.arange(-.5, len(vis_angs) + .5)
            ax.fill_between(ceiling_x, 1.0, 2, color='black', alpha=.2, lw=0)
            ax.fill_between(ceiling_x, -2, -1, color='black', alpha=.2, lw=0)
            ax.set_yticks((-1, 0, 1), size=16)
            ax.set_ylabel('occluder <-----> exemplar', size=16)
            ax.set_ylim((-1.2, 1.2))
            ax.set_xticks(ticks=x_pos, labels=vis_angs,  size=16)
            ax.set_xlim((-.5, len(vis_angs) - .5))
            ax.set_xlabel(r"visual angle ($\degree$)", size=16)
            plt.tight_layout()
            plt.savefig(outpath, dpi=300)
            plt.close()


if __name__ == '__main__':

    main()



