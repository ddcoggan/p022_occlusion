# /usr/bin/python
# Created by David Coggan on 2023 06 28
import itertools
import os
import os.path as op
import numpy as np
import pandas as pd

from config import PROJ_DIR

def ecc_to_size(ecc, method):

    def voxel_size_adjustment(voxel_size):
        my_area = 4 * 6  # 2mm isotropic
        their_area = np.sum([x * y for x, y in itertools.combinations(
            voxel_size, 2)] * 2)
        scale_factor = my_area / their_area
        return scale_factor

    if method == 'dumoulin':
        voxel_size = [3,2.5,2.5]
        unit = 'sigma'
        a = np.array([2, .4])
        b = np.array([12, 1])
        slope = (b[1] - a[1]) / (b[0] - a[0])
        intercept = a[1] - (a[0] * slope)
    else:
        voxel_size = [2, 2, 2]
        unit = 'FWHM'
        if method == 'poltoratski_4A':
            intercept, slope = 0.5, (1.4 / 4.5)
        else:
            intercept, slope = 0.4, (0.8 / 4.5)

    scale = voxel_size_adjustment(voxel_size)
    size = scale * (intercept + slope * ecc)
    if unit == 'sigma':
        size *= 2.355
    return size


def estimate_pRFs():

    eccs = np.arange(0,5,.5)
    data = {'dumoulin': [], 'poltoratski_4A': [], 'poltoratski_4B': []}

    for method, ecc in itertools.product(data, eccs):
        data[method].append(ecc_to_size(ecc, method))
    data['eccentricity'] = eccs

    pRF_estimates = pd.DataFrame(data)
    outpath = f'{PROJ_DIR}/in_vivo/fMRI/figures/pRF_estimates.csv'
    pRF_estimates.to_csv(outpath, index=False)

if __name__ == "__main__":

    estimate_pRFs()
