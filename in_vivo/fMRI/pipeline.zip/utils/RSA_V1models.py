import os
import os.path as op
import sys
import glob
import time
import pickle as pkl
import numpy as np
from types import SimpleNamespace
import shutil
import itertools
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import kendalltau, sem
from frrsa import frrsa
import json
import torch
from PIL import Image
import torchvision.transforms as transforms
from torch.utils.data import TensorDataset
import gc
from torch.profiler import profile, record_function, ProfilerActivity
from scipy import interpolate


sys.path.append(op.expanduser('~/david/master_scripts/misc'))
from plot_utils import make_legend, custom_defaults
plt.rcParams.update(custom_defaults)

from in_vivo.fMRI.scripts.utils import CFG as fMRI
from in_vivo.fMRI.scripts.utils import RSA_dataset

sys.path.append(op.expanduser('~/david/repos/vonenet'))
from vonenet.vonenet import VOneNet

PROJ_DIR = op.expanduser('~/david/projects/p022_occlusion')
FMRI_DIR = op.join(PROJ_DIR, 'in_vivo/fMRI')

similarity = 'pearson'
norm = 'all-conds'
norm_method = 'z-score'
ylabel = "Correlation ($\it{r}$)"
measurements = 64
fix_stds = [0, .125, .25, .5, 1]
vis_angs = [2.25, 4.5, 9, 18, 36]
vis_angs.reverse()
fix_stds_labels = [f'{f}' + r"$\degree$" for f in fix_stds]
vis_angs_labels = [f'{v}' + r"$\degree$" for v in vis_angs]

def main(overwrite=False):

    os.makedirs(f'{FMRI_DIR}/V1_models', exist_ok=True)
    os.chdir(f'{FMRI_DIR}/V1_models')

    evaluate_models(overwrite=False)
    compare_single_var(overwrite=True)
    compare_fix_std_vis_ang(overwrite=True)


def evaluate_models(overwrite=False):

    if not op.isfile('conditions.csv') or overwrite:
        normalize = transforms.Normalize(mean=[0.5], std=[0.5])

        # dataset
        image_dir = f'{FMRI_DIR}/exp1/stimuli/all_stimuli'
        images = sorted(glob.glob(f'{image_dir}/*'))
        dataset = torch.empty((len(images), 3, 224, 224))
        image_counter = 0
        for cond in fMRI.cond_labels['exp1']:
            for im, image in enumerate(images):
                if cond in image:
                    image_PIL = Image.open(image).convert('RGB')
                    dataset[image_counter] = transforms.ToTensor()(image_PIL)
                    image_counter += 1

        df_conds = pd.DataFrame()
        df_indices = pd.DataFrame()

        torch.no_grad()


        for fix_std, vis_ang in itertools.product(fix_stds, vis_angs):

            print(f'Measuring responses, fix_std:{fix_std}, vis_ang:{vis_ang}')

            model = VOneNet(model_arch=None, visual_degrees=vis_ang,
                            gabor_seed=1).cuda()
            out_dir = f'{PROJ_DIR}/in_silico/models/VOneNet/fMRI'

            if fix_std == 0:
                inputs = normalize(dataset).cuda()
                responses_all = model(inputs).flatten(start_dim=1).detach(
                ).cpu().numpy()
                response_mean = responses_all.mean(axis=0)
                response_std = responses_all.mean(axis=0).std(axis=0)
                response_z = response_mean / response_std
                selected_units = response_z > 3.1
                responses_final = responses_all[:, selected_units]

            else:
                scale = fix_std * 14
                responses_all = np.empty((measurements, 24, 1605632))
                for m in range(measurements):
                    print(f'Measurement {m+1}/{measurements}')
                    inputs = dataset.clone()
                    for i, image in enumerate(dataset):
                        ecc = np.abs(np.random.normal(loc=0, scale=scale))
                        ang = np.random.uniform(low=0, high=2 * np.pi)
                        x = int(ecc * np.cos(ang))
                        y = int(ecc * np.sin(ang))
                        inputs[i] = transforms.functional.affine(
                            img=image, angle=0, translate=(x, y),
                            scale=1., shear=0., fill=.5)
                    inputs = normalize(inputs).cuda()
                    responses_all[m] = model(inputs).flatten(
                        start_dim=1).detach().cpu().numpy()

                    #for i in range(24):
                    #    plt.imshow(transforms.ToPILImage()(inputs[i]))
                    #    plt.show()
                    #    time.sleep(2)
                    #    plt.imshow(transforms.ToPILImage()(
                    #        responses[1, 31, i, 0, :, :] * 100))
                    #    plt.show()
                    #    time.sleep(2)

                # select units with a z-score > 3.1
                response_mean = responses_all.mean(axis=(0,1))
                response_std = responses_all.mean(axis=0).std(axis=0)
                response_z = response_mean / response_std
                selected_units = response_z > 3.1

                # average across measurements
                responses_final = (responses_all[:, :, selected_units]
                    .reshape(2, 32, 24, -1).mean(axis=1))

            # make RSA dataset and calculate RSM
            print(f'Calculating RSM')
            os.makedirs(f'{out_dir}', exist_ok=True)
            RSM = RSA_dataset(responses=responses_final).calculate_RSM(
                norm, norm_method, similarity)

            # plot RSM
            print(f'Plotting RSM ')
            RSM.plot_RSM(
                vmin=-1, vmax=1,
                fancy=True,
                title=f'fixation std:{fix_std}, visual angle:{vis_ang}',
                labels=fMRI.cond_labels['exp1'],
                outpath=(f'{out_dir}/RSMs/fixrng-{fix_std:.3f}_visang-'
                         f'{vis_ang:.3f}.pdf'),
                measure=ylabel)

            # MDS
            print(f'Plotting MDS')
            outpath = (f'{out_dir}/MDS/fixrng-{fix_std:.3f}_visang-'
                       f'{vis_ang:.3f}.pdf')
            RSM.plot_MDS(
                title=None,
                outpath=outpath)

            # perform contrasts
            RSM.RSM_to_table()
            RSM.calculate_occlusion_robustness()
            RSM.fit_models()
            df = RSM.occlusion_robustness.copy(deep=True)
            df['vis_ang'] = vis_ang
            df['fix_std'] = fix_std
            df['num_units'] = selected_units.sum()
            df_indices = pd.concat([df_indices, df]).reset_index(drop=True)

            # condition-wise similarities
            df = RSM.RSM_table.copy(deep=True)
            df = df.drop(columns=['exemplar_a', 'exemplar_b', 'occluder_a',
                'occluder_b']).groupby(['analysis', 'level']).agg('mean'). \
                dropna().reset_index()
            df['vis_ang'] = vis_ang
            df['fix_std'] = fix_std
            df['num_units'] = selected_units.sum()
            df_conds = pd.concat([df_conds, df.copy(deep=True)]).reset_index(
                drop=True)


        df_conds.to_csv('conditions.csv')
        df_indices.to_csv('indices.csv')


# compare fix_stds for each model
def compare_single_var(overwrite=False):

    df_indices = pd.read_csv('indices.csv', index_col=0)
    df_conds = pd.read_csv('conditions.csv', index_col=0)

    # ensure levels are ordered correctly
    level_order = fMRI.occlusion_robustness_analyses[
                      'object_completion']['conds'] + \
                  fMRI.occlusion_robustness_analyses[
                      'occlusion_invariance']['conds']
    #df_conds.level = df_conds.level.astype('category').cat.reorder_categories(
    #    level_order)

    for variable, (analysis, params) in itertools.product(
            ['fix_std', 'vis_ang'], fMRI.occlusion_robustness_analyses.items()):

        out_dir = f'{analysis}'
        os.makedirs(out_dir, exist_ok=True)

        # condition-wise similarities
        outpath = (f'{out_dir}/condition-wise_similarities_{variable}.pdf')

        if not op.isfile(outpath) or overwrite:

            if variable == 'fix_std':
                df_analysis = df_conds[
                    (df_conds.analysis == analysis) &
                    (df_conds.vis_ang == 9)]
                xlabel = r"spatial jitter $\sigma$ ($\degree$)"
                xticklabels = fix_stds_labels
                df_analysis = df_analysis.sort_values(by=variable)
            else:
                df_analysis = df_conds[
                    (df_conds.analysis == analysis) &
                    (df_conds.fix_std == 0)]
                xlabel = r"visual angle of stimulus ($\degree$)"
                xticklabels = vis_angs_labels
                df_analysis = df_analysis.sort_values(by=variable,
                                                      ascending=False)
            df_analysis.level = df_analysis.level.astype(
                'category').cat.reorder_categories(
                fMRI.occlusion_robustness_analyses[
                    analysis]['conds'])

            df_means = df_analysis.pivot(index=variable, columns='level',
                                         values='similarity')

            fig, ax = plt.subplots(figsize=(4, 3))
            df_means.plot(
                kind='bar',
                rot=0,
                color=params['colours'],
                legend=False,
                ax=ax,
                width=.8)
            ax.set_yticks(np.arange(-1, 1.1, 1))
            ax.set_ylim((-.5, 1))
            ax.set_ylabel(ylabel)
            ax.set_xticks(labels=xticklabels, ticks=np.arange(5))
            #plt.text(index_x, index_y, index_texts, fontsize=16)
            plt.xlabel(xlabel)
            plt.tight_layout()
            fig.savefig(outpath)
            plt.close()

        # robustness indices
        outpath = f'{out_dir}/{params["index_label"]}_{variable}.pdf'
        if not op.isfile(outpath) or overwrite:

            # model indices
            if variable == 'fix_std':
                df_index = df_indices[
                    (df_indices.analysis == analysis) &
                    (df_indices.vis_ang == 9) &
                    (df_indices.subtype == 'norm')]
                xlabel = r"spatial jitter $\sigma$ ($\degree$)"
                df_index = df_index.sort_values(by=variable)
            else:
                df_index = df_indices[
                    (df_indices.analysis == analysis) &
                    (df_indices.fix_std == 0) &
                    (df_indices.subtype == 'norm')]
                xlabel = r"visual angle of stimulus ($\degree$)"
                df_index = df_index.sort_values(by=variable,
                                                      ascending=False)
            index_values = df_index.value.values

            # human indices
            fMRI_vals = []
            linestyles = ['solid', 'dashed', 'dotted']
            for exp, task in zip(
                    ['exp1', 'exp2', 'exp2'],
                    ['occlusion', 'occlusionAttnOn', 'occlusionAttnOff']):
                fMRI_data = pd.read_csv(
                    f'{FMRI_DIR}/{exp}/derivatives/RSA/'
                    f'{task}_space-standard/norm-all-conds_z-score/'
                    f'pearson/{analysis}/indices.csv')
                fMRI_vals.append(fMRI_data['value'][
                    (fMRI_data.level == 'group') &
                    (fMRI_data.subtype == 'norm') &
                    (fMRI_data.region == 'V1')].item())
            fig, ax = plt.subplots(figsize=(3.5, 2))
            x_pos = np.arange(len(index_values))
            ax.plot(x_pos, index_values, color='tab:purple', marker='o')
            ceiling_x = np.arange(-.5,len(fix_stds) + .5)
            ax.fill_between(ceiling_x, 1.0, 2, color='black', alpha=.2, lw=0)
            ax.fill_between(ceiling_x, 0, -1, color='black', alpha=.2, lw=0)
            ax.set_yticks((0, .5, 1), labels=['0','.5','1'])
            ax.set_ylabel(params['index_label'])
            ax.set_ylim((-0.1, 1.2))
            for fMRI_val, ls in zip(fMRI_vals, linestyles):
                ax.axhline(y=fMRI_val, xmin=-.5, xmax=len(fix_stds) + .5,
                           color='tab:blue', ls=ls)
            ax.set_xticks(ticks=x_pos, labels=df_index[variable].values)
            ax.set_xlim((-.5, len(fix_stds) - .5))
            #ax.set_title(f"{analysis.replace('_', ' ')} index")
            ax.set_xlabel(xlabel)
            plt.tight_layout()
            plt.savefig(outpath)
            plt.close()

            # legend
            labels = [
                'Human V1 (Exp. 1)',
                'Human V1 (Exp. 2, attended)',
                'Human V1 (Exp. 2, unattended)',
                'VOneNet']
            markers = [None, None, None, 'o']
            lss = ['solid', 'dashed', 'dotted', None]
            cols = ['tab:blue']*3 + ['tab:purple']
            make_legend(outpath=f'model_legend.pdf', labels=labels,
                        markers=markers, linestyles=lss, colors=cols)


def compare_fix_std_vis_ang(overwrite=False):

    ylims = [-.8, 1.0]
    df_indices = pd.read_csv('indices.csv', index_col=0)
    df_conds = pd.read_csv('conditions.csv', index_col=0)

    # ensure levels are ordered correctly
    level_order = fMRI.occlusion_robustness_analyses[
                      'object_completion']['conds'] + \
                  fMRI.occlusion_robustness_analyses[
                      'occlusion_invariance']['conds']
    df_conds.level = df_conds.level.astype('category').cat.reorder_categories(
        level_order)

    for analysis, params in fMRI.occlusion_robustness_analyses.items():

        out_dir = f'{analysis}'
        os.makedirs(out_dir, exist_ok=True)

        # condition-wise similarities
        outpath = (f'{out_dir}/condition-wise_similarities_fix_std_vis_ang.pdf')
        if not op.isfile(outpath) or overwrite:

            fig, axes = plt.subplots(5, 5, figsize=(6, 6), sharex=True,
                                     sharey=True)
            for (f, fix_std), (v, vis_ang) in itertools.product(
                    enumerate(fix_stds), enumerate(vis_angs)):
                ax = axes[f, v]
                df = df_conds[(df_conds.analysis == analysis) &
                              (df_conds.fix_std == fix_std) &
                              (df_conds.vis_ang == vis_ang)]
                df.plot(
                    x='level', y='similarity',
                    kind='bar',
                    rot=0,
                    color=params['colours'],
                    legend=False,
                    ax=ax,
                    width=1)
                ax.set_yticks(np.arange(-1, 1.1, 1))
                ax.set_ylim((-.3, 1))
                ax.set_xlim(-1.5, 4.5)
                if f == 2 and v == 0:
                    ax.set_ylabel("Correlation ($\it{r}$)", fontsize=12)
                ax.set_xticks([])
                ax.tick_params(axis='both', which='minor', bottom=False,
                               left=False)
                # plt.text(index_x, index_y, index_texts, fontsize=16)
                if f == 4:
                    ax.set_xlabel(f'{vis_ang}'+r"$\degree$", fontsize=12,
                                  labelpad=10)
            fig.subplots_adjust(left=0.25)
            left_pos = -38
            plt.text(left_pos, 7.5, r"spatial jitter $\sigma$", fontsize=12,
                     ha='center')
            for vert_pos, fix_std_label in zip(
                    np.linspace(6.5, 0.35, 5), fix_stds_labels):
                plt.text(left_pos, vert_pos, fix_std_label, fontsize=12,
                         ha='center')
            plt.text(-12.5, -1.3, "visual angle of stimulus", fontsize=12,
                     ha='center')
            #plt.tight_layout()
            fig.savefig(outpath)
            plt.close()


        # robustness indices

        # human indices
        fMRI_vals = []
        linestyles = ['solid', 'dashed', 'dotted']
        for exp, task in zip(
                ['exp1', 'exp2', 'exp2'],
                ['occlusion', 'occlusionAttnOn', 'occlusionAttnOff']):
            fMRI_data = pd.read_csv(
                f'{FMRI_DIR}/{exp}/derivatives/RSA/'
                f'{task}_space-standard/norm-all-conds_z-score/'
                f'pearson/{analysis}/indices.csv')
            fMRI_vals.append(fMRI_data['value'][
                                 (fMRI_data.level == 'group') &
                                 (fMRI_data.subtype == 'norm') &
                                 (fMRI_data.region == 'V1')].item())

        outpath = f'{out_dir}/{params["index_label"]}_fix_std_vis_ang.pdf'
        if not op.isfile(outpath) or overwrite:
            index_values = np.empty((len(fix_stds), len(vis_angs)))
            for (f, fix_std), (v, vis_ang) in itertools.product(
                    enumerate(fix_stds), enumerate(vis_angs)):
                index_values[f,v] = df_indices[
                    (df_indices.analysis == analysis) &
                    (df_indices.fix_std == fix_std) &
                    (df_indices.vis_ang == vis_ang) &
                    (df_indices.subtype == 'norm')].value.item()
            fig, ax = plt.subplots(figsize=(6, 3))
            im = ax.imshow(index_values, vmin=0, vmax=1, cmap='viridis')
            ax.tick_params(**{'length': 0})
            ax.set_xticks(np.arange(len(vis_angs)), vis_angs_labels)
            ax.set_yticks(np.arange(len(fix_stds)), fix_stds_labels)
            ax.tick_params(direction='in')
            ax.spines['top'].set_visible(True)
            ax.spines['right'].set_visible(True)
            ax.set_xlabel(r"visual angle of stimulus")
            ax.set_ylabel(r"spatial jitter $\sigma$")
            fig.subplots_adjust(right=0.7)
            cbar = fig.colorbar(im, fraction=0.0453, ax=ax)
            cbar.set_ticks(ticks=[0, 1] + fMRI_vals,
                           labels=['0', '1'] + [
                'Human V1 (Exp. 1)',
                'Human V1 (Exp. 2, attended)',
                'Human V1 (Exp. 2, unattended)'], fontsize=8)
            plt.text(4, 4, f'{index_values[4,4]:.2f}', fontsize=8,
                     ha='center', va='center')
            ax.set_title(f"{analysis.replace('_', ' ')} index")
            plt.tight_layout()
            plt.savefig(outpath)
            plt.close()


if __name__ == '__main__':

    main()



